# Chlorophytum comosum (spider plant)

![Preview of Chlorophytum comosum](pic/chlorophytum-comosum.png)

Chlorophytum comosum, otherwise known as spider plant, is a perennial flowering
plant, often used as groundcover, to border paths, or as an indoor plant. It is
a type of air filtering plant, and can be used to reduce indoor air pollution.

The model is provided simply as a single "tuft" of leaves. It is expected to be
instanced many times and placed in an environment.

## Materials

The colours have been calibrated with Macbethcal to an actual Chlorophytum
comosum plant in Australia, but the specularity and roughness values are
guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/chlorophytum-comosum/obj/model.rad
```

In order to preserve memory in the occasion of including many instances of this
model, an `.oct` octree is also provided, and so you can instance it in your
scene as follows:

```
void instance model
1 lib/chlorophytum-comosum/obj/model.oct
0
0
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
