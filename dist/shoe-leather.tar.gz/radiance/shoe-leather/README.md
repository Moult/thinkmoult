# Shoe leather

![Preview of the leather shoe](pic/shoe-leather.png)

This is a black shoe I bought from some men's fashion shop. It's a a typical
man's black work / office shoes. It looks professional. It has a left shoe and a
right shoe.

I'm sorry, I don't know much about shoes.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/shoe-leather/obj/left-shoe.rad
!xform lib/shoe-leather/obj/right-shoe.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
