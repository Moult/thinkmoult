# Plug round generic

![Preview of the generic round plug](pic/plug-round-generic.png)

This is a free 3D model of a generic round plug. All sorts of electrical
appliances have plugs and so this is a generic one you can use anywhere. Most of
them are made of black rubber, which I've measured here.

The pins are not included in this model, and neither is the wire. This is
because the plug is likely to be plugged into a socket. If you need a socket in
Australia, there is a 3D model of an [Australian double
GPO](https://thinkmoult.com/gpo-double-australia-free-3d-model.html). Wires vary
based on what appliance you have, and so you will need to model the wire
yourself.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/plug-round-generic/obj/model.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
