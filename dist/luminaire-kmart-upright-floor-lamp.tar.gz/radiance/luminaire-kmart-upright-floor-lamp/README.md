# Luminaire KMart upright floor lamp

![Preview of the KMart upright floor lamp luminaire](pic/luminaire-kmart-upright-floor-lamp.png)

This is an [upright KMart floor
lamp](https://www.kmart.com.au/product/upright-floor-lamp/1445801) sold by KMart
in Australia. It has a maximum lamp / globe capacity of 60W. It has a
translucent plastic shade. There is a wire which is not included, which should
be fitted into the two wire clips along its stand. This model does not come with
a lamp / globe.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/luminaire-kmart-upright-floor-lamp/obj/model.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
