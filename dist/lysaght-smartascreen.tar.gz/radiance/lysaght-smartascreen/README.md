# Lysaght Smartascreen

![Preview of the Lysaght Smartascreen fence model](pic/lysaght-smartascreen.png)

This [Lysaght Smartascreen](https://www.lysaght.com/products/smartascreen) fence
is a profiled metal sheeting fence sold by Lysaght in Australia. It is made from
Colorbond steel and comes in a range of Colorbond colours.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

This colour is a dark grey, at a guess it might be the "Basalt" Colorbond
colour, but this is only a guess.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/lysaght-smartascreen/obj/model.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
