# Shoe rack Bunnings 2 tier white wooden

![Preview of the Bunnings 2-tier, white, wooden shoe rack](pic/shoe-rack-bunnings-2-tier-white-wooden.png)

This is a [2-tier, white, wooden shoe rack sold by Bunnings in
Australia](https://www.bunnings.com.au/all-set-2-tier-white-wooden-shoe-rack_p2583482).
It's pine wood and painted white. Fixings are hidden.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/shoe-rack-bunnings-2-tier-white-wooden/obj/model.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
