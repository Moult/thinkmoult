# Keyboard Filco Majestouch 2 Tenkeyless

![Preview of the Filco Majestouch 2 Tenkeyless keyboard](pic/keyboard-filco-majestouch-2-tenkeyless.png)

This is a free 3D model of the Filco Majestouch 2 Tenkeyless keyboard. Being a
tenkeyless keyboard, it lacks a numpad. It is a fairly generic design but sports
key decals affixed to the front face of each key, as opposed to on the top. It
is a mechanical keyboard and has blue LEDs signifiying modifier activation.

Another [keyboard
photograph](https://thinkmoult.com/brand-new-gentoo-desktop-computer.html) is
available on the thinkMoult blog.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/keyboard-filco-majestouch-2-tenkeyless/obj/keyboard-filco-majestouch-2-tenkeyless.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
