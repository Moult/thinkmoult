# Book "Rendering with Radiance"

![Preview of the book, "Rendering with Radiance"](pic/book-rendering-with-radiance.png)

The book "Rendering with Radiance" by Greg Ward Larson and Rob A. Shakespeare
is the main textbook behind the Radiance rendering engine. This is a free 3D
model of the third edition softcover book. It can be used as entourage to add
believability to a scene.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/book-rendering-with-radiance/obj/book-rendering-with-radiance.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
