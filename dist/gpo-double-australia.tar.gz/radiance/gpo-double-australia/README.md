# GPO Double Australia

![Preview of the double GPO in Australia](pic/gpo-double-australia.png)

This is a typical double GPO in Australia i.e. Australian plug systems, standard
AS/NZS 3112 (Type I). It's also the same as the ones used in New Zealand, and
similar to those used in China. I had one in my house and decided to measure and
model it. No textures required.

GPOs in Australia are usually set at 450mm to their horizontal centerline above
the finished floor level. An exception occurs in some places such as disabled
bathrooms where they are set at 600mm in order to make it easier for disabled
access.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/gpo-double-australia/obj/model.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
