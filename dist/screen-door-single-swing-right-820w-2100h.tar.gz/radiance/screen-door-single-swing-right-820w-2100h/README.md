# Screen door single swing right 820w 2100h

![Preview of the metal screen door](pic/screen-door-single-swing-right-820w-2100h.png)

This is an off-white metal screen door. It has a fine mesh or flyscreen in the
centre of its metal frame. It has a thin 20mm metal right and left jamb, and an
80mm metal top jamb.

No hardware is modeled, although in reality it has a handle. No hinges are
modeled.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/screen-door-single-swing-right-820w-2100h/obj/model.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
