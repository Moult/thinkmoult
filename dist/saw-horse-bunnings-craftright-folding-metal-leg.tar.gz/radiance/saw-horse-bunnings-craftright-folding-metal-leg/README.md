# Saw horse Bunnings Craftright folding metal leg

![Preview of the Craftright folding metal leg saw horse sold by Bunnings](pic/saw-horse-bunnings-craftright-folding-metal-leg.png)

This is a 3D model of a [foldable saw horse by
Craftright](https://www.bunnings.com.au/craftright-folding-metal-leg-saw-horse_p5710162).
It is sold by Bunnings in Australia. The saw horse has two orange folding metal
legs, which have metal stops bolted to a timber plank with wingnuts, and rubber
feet.

## Materials

The colours have been calibrated with Macbethcal but the specularity and
roughness values are guessed.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/saw-horse-bunnings-craftright-folding-metal-leg/obj/model.rad
```

## Authors

This model was created by [Dion Moult](https://thinkmoult.com).
