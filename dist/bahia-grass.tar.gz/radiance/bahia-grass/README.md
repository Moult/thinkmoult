# Bahia grass

![Preview of bahia grass](pic/bahia-grass.png)

Bahia grass is a fairly typical looking turf grass to the untrained eye. This
patch of grass is not mown and contains 4 varieties of leaves which are randomly
scattered. The grass is seeding and the distinctive V-shape of the seeds are
visible. This is a low-polygon model that mimicks the shape of the grass, but is
not scientifically detailed.

This model is provided as a circular patch of grass, which is relatively sparse.
It is assumed that this patch will be instanced many times with different
translated locations, rotations, and scales in order to build up the illusion of
a field of grass.

## Materials

The colours have been calibrated with Macbethcal to a patch of buffalo grass in
Australia, but the specularity and roughness values are guessed. Therefore the
green of the grass should be within the ballpark of believable grass colours,
but it should not be treated as a proper representation of the grass species.

## Usage

This Radiance model follows the [Radiance Filesystem Hierarchy
Standard](https://thinkmoult.com/proposed-radiance-filesystem-hierarchy-standard.html). As
such, please run `make lib` to build the Radiance mesh file. Once done, you can
use this in your scene by:

```
!xform lib/bahia-grass/obj/model.rad
```

In order to preserve memory in the occasion of including many instances of this
model, an `.oct` octree is also provided, and so you can instance it in your
scene as follows:

```
void instance model
1 lib/bahia-grass/obj/model.oct
0
0
```

## Authors

This model was originally created by Marco Pavanello and Joseph Dowling in their
[free Blender grass pack](https://3d-wolf.com/products/grass.html) licensed
under GPL.

This model was modified by [Dion Moult](https://thinkmoult.com) in order to
create circular patches, follow the RFHS requirements such as naming and model
scale, and add Radiance material definitions.

The original content does not specify which version of GPL it was licensed for,
and this creates some confusion, especially as GPLv3 is much more specific about
compatibility. Therefore this model is licensed under the Creative Commons
Attribution 4.0 license (CC-BY 4.0).
